public class Gradebook {

    private String student;

    private int hw1;
    private int hw2;
    private int hw3;
    private int exam;

    public Gradebook(String student_name, int hw1, int hw2, int hw3, int exam) {
        this.student = student_name;
        this.hw1 = hw1;
        this.hw2 = hw2;
        this.hw3 = hw3;
        this.exam = exam;
    }

    public String getStudent() { return this.student; }

    public int getHw1() {
        return this.hw1;
    }

    public int getHw2() {
        return this.hw2;
    }

    public int getHw3() {
        return this.hw3;
    }

    public int getExam() {
        return this.exam;
    }



}