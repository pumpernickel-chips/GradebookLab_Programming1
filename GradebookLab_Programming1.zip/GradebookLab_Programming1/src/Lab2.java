import java.io.File;
import java.io.FileNotFoundException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Lab2 {
    public static void main(String[] arg) {
        String gradebook_path = ask_for_file();
        Gradebook student_data = read_file_to_gradebook(gradebook_path);
        double final_grade = calculate_grade(student_data);
        System.out.println("Final Grade: " + final_grade);


    }
    public static String ask_for_file() {
        Scanner filename;
        filename = new Scanner(System.in);
        System.out.print("Please Enter File Name: ");
        String gradebook_path = filename.nextLine();
        boolean file_extension = (gradebook_path.endsWith(".grd"));
        if(!file_extension) {
            gradebook_path=gradebook_path + ".grd";
        }
        return gradebook_path;
    }
    public static Gradebook read_file_to_gradebook(String gradebook_path) {
        try {
            File gradebook_file;
            gradebook_file= new File(gradebook_path);
            Scanner gradebook_reader = new Scanner(gradebook_file);
            String student_name = gradebook_reader.nextLine();
            int hw1 = gradebook_reader.nextInt();
            int hw2 = gradebook_reader.nextInt();
            int hw3 = gradebook_reader.nextInt();
            int exam = gradebook_reader.nextInt();
            gradebook_reader.close();
            Gradebook student_data = new Gradebook(student_name, hw1, hw2, hw3, exam);
            return student_data;
        } catch (FileNotFoundException e) {
            System.out.println("Error: File Not Found");
            System.out.println("");
        } catch (NoSuchElementException e) {
            System.out.println("Error: Missing or Invalid Grades");
            System.out.println("");
        } catch (NumberFormatException e) {
            System.out.println("Error: Invalid Format");
            System.out.println("");
        }
        return null;
    }
    public static double calculate_grade(Gradebook student_data) {
        String student_name = student_data.getStudent();
        int hw1 = student_data.getHw1();
        int hw2 = student_data.getHw2();
        int hw3 = student_data.getHw3();
        int exam = student_data.getExam();
        System.out.println("Final Grades for " + student_name + ":");
        System.out.println("  HW 1 - " + hw1);
        System.out.println("  HW 2 - " + hw2);
        System.out.println("  HW 3 - " + hw3);
        System.out.println("  EXAM - " + exam);
        double final_grade;
        final_grade = (0.2 * hw1 + 0.2 * hw2 + 0.2 * hw3 + 0.4 * exam);
        return final_grade;
    }
}
